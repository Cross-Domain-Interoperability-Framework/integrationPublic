This simple sample of DDI-CDI employs the CDIF profile for Data Descripition.

Please note that there are no coded variables in the example - these would be represented using SKOS in CDIF.
Also, the structure of the JSON-LD might change - the RDF content is correct, but there may be new rules for how this would look when integrated with a Schema.org wrapper in CDIF. This is under discussion as of November 2025.